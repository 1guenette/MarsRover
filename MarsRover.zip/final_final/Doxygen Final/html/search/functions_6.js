var searchData=
[
  ['main',['main',['../main_8c.html#acdef7a1fd863a6d3770c1268cb06add3',1,'main.c']]],
  ['move_5fservo',['move_servo',['../main_8c.html#a15703b8f962bb0bccacea54e5ffd3453',1,'main.c']]],
  ['movement',['movement',['../movement_8c.html#a8c23b3d6b5e9a24d0dba9dfb45043f7a',1,'movement(oi_t *sensor_data, int meters):&#160;movement.c'],['../movement_8h.html#a8c23b3d6b5e9a24d0dba9dfb45043f7a',1,'movement(oi_t *sensor_data, int meters):&#160;movement.c']]]
];
