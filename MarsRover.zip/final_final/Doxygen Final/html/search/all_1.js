var searchData=
[
  ['calculateobject',['calculateObject',['../main_8c.html#a47da6bf36203c271428ca6b247926507',1,'main.c']]],
  ['clifffrontdetect',['cliffFrontDetect',['../main_8c.html#aaf0c5449c79b00d38afc4f93f61bb60d',1,'main.c']]],
  ['clock_5ftimer_5finit',['clock_timer_init',['../main_8c.html#a83900ae9d3acd0600075a437574ef879',1,'main.c']]]
];
