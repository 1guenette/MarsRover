var searchData=
[
  ['wifi_5fstart',['WiFi_start',['../_wi_fi_8c.html#aba0998b0179f820b92f584529c3213ee',1,'WiFi_start(char *psk):&#160;WiFi.c'],['../_wi_fi_8h.html#aba0998b0179f820b92f584529c3213ee',1,'WiFi_start(char *psk):&#160;WiFi.c']]],
  ['wifi_5fstop',['WiFi_stop',['../_wi_fi_8c.html#aa52634f2d4aab484cbc8d2d334cb0aba',1,'WiFi_stop():&#160;WiFi.c'],['../_wi_fi_8h.html#aa52634f2d4aab484cbc8d2d334cb0aba',1,'WiFi_stop():&#160;WiFi.c']]]
];
