var searchData=
[
  ['timer_2ec',['Timer.c',['../_timer_8c.html',1,'']]],
  ['timer_2eh',['Timer.h',['../_timer_8h.html',1,'']]],
  ['timer3b_5fhandler',['TIMER3B_Handler',['../ping_8c.html#a0169bae47cb00f30dc5936d788438802',1,'ping.c']]],
  ['timer_5fwaitmillis',['timer_waitMillis',['../_timer_8c.html#a7e2a3b4520e885e5e7d40fa87e242a75',1,'timer_waitMillis(uint32_t millis):&#160;Timer.c'],['../_timer_8h.html#a7e2a3b4520e885e5e7d40fa87e242a75',1,'timer_waitMillis(uint32_t millis):&#160;Timer.c']]],
  ['turn',['turn',['../movement_8c.html#ae05e69952f674603828d413c1500947d',1,'turn(oi_t *sensor_data, int degrees):&#160;movement.c'],['../movement_8h.html#ae05e69952f674603828d413c1500947d',1,'turn(oi_t *sensor_data, int degrees):&#160;movement.c']]]
];
