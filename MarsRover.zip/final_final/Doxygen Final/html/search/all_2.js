var searchData=
[
  ['detect2',['detect2',['../main_8c.html#a2f6b5bc3e627c0fd4352e98b33ecb733',1,'main.c']]],
  ['detect3',['detect3',['../main_8c.html#a00bd00215aa8e3f40012a3ec7aa6e635',1,'main.c']]],
  ['detect4',['detect4',['../main_8c.html#a55be1b0d31f0a562e6b6098ea0fa8ad8',1,'main.c']]]
];
