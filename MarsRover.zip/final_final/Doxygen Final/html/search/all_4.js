var searchData=
[
  ['ir_2ec',['ir.c',['../ir_8c.html',1,'']]],
  ['ir_2eh',['ir.h',['../ir_8h.html',1,'']]],
  ['ir_5fgetdistance',['ir_getDistance',['../ir_8c.html#af8e0e15988dd1a4f924148bc6fad4616',1,'ir_getDistance():&#160;ir.c'],['../ir_8h.html#af8e0e15988dd1a4f924148bc6fad4616',1,'ir_getDistance():&#160;ir.c']]],
  ['ir_5fgetvalue',['ir_getValue',['../ir_8c.html#a504f0d386815f966960ecbbb4e6dc972',1,'ir.c']]],
  ['ir_5finit',['ir_init',['../ir_8c.html#a398213820d1862c262f45bb51a4bb934',1,'ir.c']]]
];
