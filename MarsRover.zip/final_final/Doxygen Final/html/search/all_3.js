var searchData=
[
  ['getdegrees',['getDegrees',['../open__interface_8c.html#a06111b7bdb73f95e0d51d4656beb7c6e',1,'open_interface.c']]],
  ['getdiameter',['getDiameter',['../main_8c.html#a5168683073f8290b20dd6b556a5bbd60',1,'main.c']]],
  ['go_5fcharge',['go_charge',['../open__interface_8c.html#a6c701c5d6642b0f7128b03542a09ed76',1,'open_interface.c']]]
];
